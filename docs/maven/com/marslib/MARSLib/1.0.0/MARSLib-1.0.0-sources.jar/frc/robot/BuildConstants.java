package frc.robot;

/** Automatically generated file containing build version information. */
public final class BuildConstants {
  public static final String MAVEN_GROUP = "";
  public static final String MAVEN_NAME = "MARSLib";
  public static final String VERSION = "unspecified";
  public static final int GIT_REVISION = 278;
  public static final String GIT_SHA = "eac3006da2173f9a052891d473c599478fc4238c";
  public static final String GIT_DATE = "2026-04-13 13:13:48";
  public static final String GIT_BRANCH = "master";
  public static final String BUILD_DATE = "2026-04-13 17:14:22 UTC";
  public static final long BUILD_UNIX_TIME = 1776100462676L;
  public static final int DIRTY = 1;

  private BuildConstants() {}
}
