package frc.robot;

/** Automatically generated file containing build version information. */
public final class BuildConstants {
  public static final String MAVEN_GROUP = "";
  public static final String MAVEN_NAME = "MARSLib";
  public static final String VERSION = "unspecified";
  public static final int GIT_REVISION = 305;
  public static final String GIT_SHA = "976faaefbf7011f2b53823a226cd6fddf97e2216";
  public static final String GIT_DATE = "2026-04-13 16:01:17";
  public static final String GIT_BRANCH = "master";
  public static final String BUILD_DATE = "2026-04-13 20:02:03 UTC";
  public static final long BUILD_UNIX_TIME = 1776110523905L;
  public static final int DIRTY = 1;

  private BuildConstants() {}
}
