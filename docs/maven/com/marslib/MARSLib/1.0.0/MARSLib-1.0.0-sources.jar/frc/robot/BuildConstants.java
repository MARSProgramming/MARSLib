package frc.robot;

/** Automatically generated file containing build version information. */
public final class BuildConstants {
  public static final String MAVEN_GROUP = "";
  public static final String MAVEN_NAME = "MARSLib";
  public static final String VERSION = "unspecified";
  public static final int GIT_REVISION = 335;
  public static final String GIT_SHA = "0a025957a18cb9eb6bda5831a5b1edbdc0e9157d";
  public static final String GIT_DATE = "2026-04-13 18:26:58";
  public static final String GIT_BRANCH = "master";
  public static final String BUILD_DATE = "2026-04-13 22:27:38 UTC";
  public static final long BUILD_UNIX_TIME = 1776119258458L;
  public static final int DIRTY = 1;

  private BuildConstants() {}
}
