package frc.robot;

/** Automatically generated file containing build version information. */
public final class BuildConstants {
  public static final String MAVEN_GROUP = "";
  public static final String MAVEN_NAME = "MARSLib";
  public static final String VERSION = "unspecified";
  public static final int GIT_REVISION = 339;
  public static final String GIT_SHA = "b4728e34128548af64d0e8ac704d05e95cbef777";
  public static final String GIT_DATE = "2026-04-13 18:40:37";
  public static final String GIT_BRANCH = "master";
  public static final String BUILD_DATE = "2026-04-13 22:41:17 UTC";
  public static final long BUILD_UNIX_TIME = 1776120077050L;
  public static final int DIRTY = 1;

  private BuildConstants() {}
}
