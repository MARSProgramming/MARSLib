package frc.robot;

/** Automatically generated file containing build version information. */
public final class BuildConstants {
  public static final String MAVEN_GROUP = "";
  public static final String MAVEN_NAME = "MARSLib";
  public static final String VERSION = "unspecified";
  public static final int GIT_REVISION = 272;
  public static final String GIT_SHA = "85019738afe3d195eb49d91e3e400ab9da6cf234";
  public static final String GIT_DATE = "2026-04-13 13:00:15";
  public static final String GIT_BRANCH = "master";
  public static final String BUILD_DATE = "2026-04-13 17:00:56 UTC";
  public static final long BUILD_UNIX_TIME = 1776099656180L;
  public static final int DIRTY = 1;

  private BuildConstants() {}
}
