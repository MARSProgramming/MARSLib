package frc.robot;

/** Automatically generated file containing build version information. */
public final class BuildConstants {
  public static final String MAVEN_GROUP = "";
  public static final String MAVEN_NAME = "MARSLib";
  public static final String VERSION = "unspecified";
  public static final int GIT_REVISION = 330;
  public static final String GIT_SHA = "c1fc9ae7317dadd1c1fa1fbb98230c8050a11ff6";
  public static final String GIT_DATE = "2026-04-13 18:08:02";
  public static final String GIT_BRANCH = "master";
  public static final String BUILD_DATE = "2026-04-13 22:08:51 UTC";
  public static final long BUILD_UNIX_TIME = 1776118131660L;
  public static final int DIRTY = 1;

  private BuildConstants() {}
}
