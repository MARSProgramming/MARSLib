package frc.robot;

/** Automatically generated file containing build version information. */
public final class BuildConstants {
  public static final String MAVEN_GROUP = "";
  public static final String MAVEN_NAME = "MARSLib";
  public static final String VERSION = "unspecified";
  public static final int GIT_REVISION = 288;
  public static final String GIT_SHA = "6e3ee1e5b4295e6d81d77d525776b2f044c23e59";
  public static final String GIT_DATE = "2026-04-13 13:46:15";
  public static final String GIT_BRANCH = "master";
  public static final String BUILD_DATE = "2026-04-13 17:47:22 UTC";
  public static final long BUILD_UNIX_TIME = 1776102442900L;
  public static final int DIRTY = 1;

  private BuildConstants() {}
}
