package frc.robot;

/** Automatically generated file containing build version information. */
public final class BuildConstants {
  public static final String MAVEN_GROUP = "";
  public static final String MAVEN_NAME = "MARSLib";
  public static final String VERSION = "unspecified";
  public static final int GIT_REVISION = 294;
  public static final String GIT_SHA = "e40da3275d4a8fc855036b0b8c4b1a16dd56a635";
  public static final String GIT_DATE = "2026-04-13 14:02:20";
  public static final String GIT_BRANCH = "master";
  public static final String BUILD_DATE = "2026-04-13 18:03:05 UTC";
  public static final long BUILD_UNIX_TIME = 1776103385127L;
  public static final int DIRTY = 1;

  private BuildConstants() {}
}
