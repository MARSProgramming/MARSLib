package frc.robot;

/** Automatically generated file containing build version information. */
public final class BuildConstants {
  public static final String MAVEN_GROUP = "";
  public static final String MAVEN_NAME = "MARSLib";
  public static final String VERSION = "unspecified";
  public static final int GIT_REVISION = 290;
  public static final String GIT_SHA = "fcb6e035713fa2b05e52e95b206a1ed93115ac6d";
  public static final String GIT_DATE = "2026-04-13 13:51:15";
  public static final String GIT_BRANCH = "master";
  public static final String BUILD_DATE = "2026-04-13 17:51:58 UTC";
  public static final long BUILD_UNIX_TIME = 1776102718918L;
  public static final int DIRTY = 1;

  private BuildConstants() {}
}
