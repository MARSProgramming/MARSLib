package frc.robot;

/** Automatically generated file containing build version information. */
public final class BuildConstants {
  public static final String MAVEN_GROUP = "";
  public static final String MAVEN_NAME = "MARSLib";
  public static final String VERSION = "unspecified";
  public static final int GIT_REVISION = 284;
  public static final String GIT_SHA = "02d121b103c58e450ce130260b4a2aefbe3ae763";
  public static final String GIT_DATE = "2026-04-13 13:37:09";
  public static final String GIT_BRANCH = "master";
  public static final String BUILD_DATE = "2026-04-13 17:37:45 UTC";
  public static final long BUILD_UNIX_TIME = 1776101865841L;
  public static final int DIRTY = 1;

  private BuildConstants() {}
}
