package frc.robot;

/** Automatically generated file containing build version information. */
public final class BuildConstants {
  public static final String MAVEN_GROUP = "";
  public static final String MAVEN_NAME = "MARSLib";
  public static final String VERSION = "unspecified";
  public static final int GIT_REVISION = 337;
  public static final String GIT_SHA = "43366adf6765833549d667702d9d8956cc3d627d";
  public static final String GIT_DATE = "2026-04-13 18:32:49";
  public static final String GIT_BRANCH = "master";
  public static final String BUILD_DATE = "2026-04-13 22:33:28 UTC";
  public static final long BUILD_UNIX_TIME = 1776119608698L;
  public static final int DIRTY = 1;

  private BuildConstants() {}
}
