package frc.robot;

/** Automatically generated file containing build version information. */
public final class BuildConstants {
  public static final String MAVEN_GROUP = "";
  public static final String MAVEN_NAME = "MARSLib";
  public static final String VERSION = "unspecified";
  public static final int GIT_REVISION = 333;
  public static final String GIT_SHA = "88054e37c97304f6274c2e56b7a6ab22bb056c5e";
  public static final String GIT_DATE = "2026-04-13 18:21:10";
  public static final String GIT_BRANCH = "master";
  public static final String BUILD_DATE = "2026-04-13 22:21:47 UTC";
  public static final long BUILD_UNIX_TIME = 1776118907527L;
  public static final int DIRTY = 1;

  private BuildConstants() {}
}
