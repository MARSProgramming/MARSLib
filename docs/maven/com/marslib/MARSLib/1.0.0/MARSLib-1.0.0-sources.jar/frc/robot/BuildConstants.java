package frc.robot;

/** Automatically generated file containing build version information. */
public final class BuildConstants {
  public static final String MAVEN_GROUP = "";
  public static final String MAVEN_NAME = "MARSLib";
  public static final String VERSION = "unspecified";
  public static final int GIT_REVISION = 324;
  public static final String GIT_SHA = "839737286929687ef43e8d68c41e7d60cce31472";
  public static final String GIT_DATE = "2026-04-13 17:48:21";
  public static final String GIT_BRANCH = "master";
  public static final String BUILD_DATE = "2026-04-13 21:49:01 UTC";
  public static final long BUILD_UNIX_TIME = 1776116941565L;
  public static final int DIRTY = 1;

  private BuildConstants() {}
}
