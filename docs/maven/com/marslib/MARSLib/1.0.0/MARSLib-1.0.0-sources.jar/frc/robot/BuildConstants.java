package frc.robot;

/** Automatically generated file containing build version information. */
public final class BuildConstants {
  public static final String MAVEN_GROUP = "";
  public static final String MAVEN_NAME = "MARSLib";
  public static final String VERSION = "unspecified";
  public static final int GIT_REVISION = 326;
  public static final String GIT_SHA = "1f247d1bfe521ec04fb1c8219756ff96dbe95a9b";
  public static final String GIT_DATE = "2026-04-13 17:55:56";
  public static final String GIT_BRANCH = "master";
  public static final String BUILD_DATE = "2026-04-13 21:56:45 UTC";
  public static final long BUILD_UNIX_TIME = 1776117405573L;
  public static final int DIRTY = 1;

  private BuildConstants() {}
}
