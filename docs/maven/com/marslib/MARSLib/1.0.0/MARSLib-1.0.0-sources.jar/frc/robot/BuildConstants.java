package frc.robot;

/** Automatically generated file containing build version information. */
public final class BuildConstants {
  public static final String MAVEN_GROUP = "";
  public static final String MAVEN_NAME = "MARSLib";
  public static final String VERSION = "unspecified";
  public static final int GIT_REVISION = 296;
  public static final String GIT_SHA = "afb0d35656328824f40982b966541fdeed9e59be";
  public static final String GIT_DATE = "2026-04-13 14:05:57";
  public static final String GIT_BRANCH = "master";
  public static final String BUILD_DATE = "2026-04-13 18:06:42 UTC";
  public static final long BUILD_UNIX_TIME = 1776103602593L;
  public static final int DIRTY = 1;

  private BuildConstants() {}
}
