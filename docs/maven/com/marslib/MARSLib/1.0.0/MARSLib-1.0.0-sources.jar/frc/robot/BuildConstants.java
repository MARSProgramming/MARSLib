package frc.robot;

/** Automatically generated file containing build version information. */
public final class BuildConstants {
  public static final String MAVEN_GROUP = "";
  public static final String MAVEN_NAME = "MARSLib";
  public static final String VERSION = "unspecified";
  public static final int GIT_REVISION = 315;
  public static final String GIT_SHA = "ae96dafbfa3a5ba3a72580d997e793f3e79caa30";
  public static final String GIT_DATE = "2026-04-13 17:08:32";
  public static final String GIT_BRANCH = "master";
  public static final String BUILD_DATE = "2026-04-13 21:09:12 UTC";
  public static final long BUILD_UNIX_TIME = 1776114552748L;
  public static final int DIRTY = 1;

  private BuildConstants() {}
}
