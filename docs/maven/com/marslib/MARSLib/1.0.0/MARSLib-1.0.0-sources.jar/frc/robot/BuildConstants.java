package frc.robot;

/** Automatically generated file containing build version information. */
public final class BuildConstants {
  public static final String MAVEN_GROUP = "";
  public static final String MAVEN_NAME = "MARSLib";
  public static final String VERSION = "unspecified";
  public static final int GIT_REVISION = 311;
  public static final String GIT_SHA = "9853d3d04191ff1ae2a647bedd6d7c89f14a941d";
  public static final String GIT_DATE = "2026-04-13 16:39:20";
  public static final String GIT_BRANCH = "master";
  public static final String BUILD_DATE = "2026-04-13 20:40:00 UTC";
  public static final long BUILD_UNIX_TIME = 1776112800400L;
  public static final int DIRTY = 1;

  private BuildConstants() {}
}
