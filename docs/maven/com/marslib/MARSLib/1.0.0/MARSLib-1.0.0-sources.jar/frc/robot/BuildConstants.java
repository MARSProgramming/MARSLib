package frc.robot;

/** Automatically generated file containing build version information. */
public final class BuildConstants {
  public static final String MAVEN_GROUP = "";
  public static final String MAVEN_NAME = "MARSLib";
  public static final String VERSION = "unspecified";
  public static final int GIT_REVISION = 309;
  public static final String GIT_SHA = "91a148fc41eefdc07ac0f122ab29db24d0c0e4a4";
  public static final String GIT_DATE = "2026-04-13 16:33:22";
  public static final String GIT_BRANCH = "master";
  public static final String BUILD_DATE = "2026-04-13 20:34:00 UTC";
  public static final long BUILD_UNIX_TIME = 1776112440792L;
  public static final int DIRTY = 1;

  private BuildConstants() {}
}
