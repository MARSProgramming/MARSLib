package frc.robot;

/** Automatically generated file containing build version information. */
public final class BuildConstants {
  public static final String MAVEN_GROUP = "";
  public static final String MAVEN_NAME = "MARSLib";
  public static final String VERSION = "unspecified";
  public static final int GIT_REVISION = 313;
  public static final String GIT_SHA = "8b2341d51917efe744a812bb84bbddacefc5fc4c";
  public static final String GIT_DATE = "2026-04-13 16:59:35";
  public static final String GIT_BRANCH = "master";
  public static final String BUILD_DATE = "2026-04-13 21:00:23 UTC";
  public static final long BUILD_UNIX_TIME = 1776114023732L;
  public static final int DIRTY = 1;

  private BuildConstants() {}
}
