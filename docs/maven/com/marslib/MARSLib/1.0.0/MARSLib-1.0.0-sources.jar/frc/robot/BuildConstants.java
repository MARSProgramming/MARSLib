package frc.robot;

/** Automatically generated file containing build version information. */
public final class BuildConstants {
  public static final String MAVEN_GROUP = "";
  public static final String MAVEN_NAME = "MARSLib";
  public static final String VERSION = "unspecified";
  public static final int GIT_REVISION = 307;
  public static final String GIT_SHA = "eedecab0138ef2bbf65de7a32a8de2ba07ec163b";
  public static final String GIT_DATE = "2026-04-13 16:21:34";
  public static final String GIT_BRANCH = "master";
  public static final String BUILD_DATE = "2026-04-13 20:22:16 UTC";
  public static final long BUILD_UNIX_TIME = 1776111736408L;
  public static final int DIRTY = 1;

  private BuildConstants() {}
}
