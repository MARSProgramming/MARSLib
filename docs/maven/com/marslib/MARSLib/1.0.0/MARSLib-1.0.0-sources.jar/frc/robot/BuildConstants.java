package frc.robot;

/** Automatically generated file containing build version information. */
public final class BuildConstants {
  public static final String MAVEN_GROUP = "";
  public static final String MAVEN_NAME = "MARSLib";
  public static final String VERSION = "unspecified";
  public static final int GIT_REVISION = 328;
  public static final String GIT_SHA = "e0f57fc54576186681da2ea09c40115bdf2abd0a";
  public static final String GIT_DATE = "2026-04-13 18:00:59";
  public static final String GIT_BRANCH = "master";
  public static final String BUILD_DATE = "2026-04-13 22:01:38 UTC";
  public static final long BUILD_UNIX_TIME = 1776117698290L;
  public static final int DIRTY = 1;

  private BuildConstants() {}
}
