package frc.robot;

/** Automatically generated file containing build version information. */
public final class BuildConstants {
  public static final String MAVEN_GROUP = "";
  public static final String MAVEN_NAME = "MARSLib";
  public static final String VERSION = "unspecified";
  public static final int GIT_REVISION = 282;
  public static final String GIT_SHA = "a9cce2bc12529c81f45a5f9b6dbcc576db9364d0";
  public static final String GIT_DATE = "2026-04-13 13:30:58";
  public static final String GIT_BRANCH = "master";
  public static final String BUILD_DATE = "2026-04-13 17:31:50 UTC";
  public static final long BUILD_UNIX_TIME = 1776101510970L;
  public static final int DIRTY = 1;

  private BuildConstants() {}
}
