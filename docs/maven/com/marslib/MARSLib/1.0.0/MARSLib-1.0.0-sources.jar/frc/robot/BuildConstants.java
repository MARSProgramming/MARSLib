package frc.robot;

/** Automatically generated file containing build version information. */
public final class BuildConstants {
  public static final String MAVEN_GROUP = "";
  public static final String MAVEN_NAME = "MARSLib";
  public static final String VERSION = "unspecified";
  public static final int GIT_REVISION = 303;
  public static final String GIT_SHA = "f5bb4efb7b06f59045f56fee5aa956e73672aab3";
  public static final String GIT_DATE = "2026-04-13 15:49:12";
  public static final String GIT_BRANCH = "master";
  public static final String BUILD_DATE = "2026-04-13 19:49:49 UTC";
  public static final long BUILD_UNIX_TIME = 1776109789429L;
  public static final int DIRTY = 1;

  private BuildConstants() {}
}
