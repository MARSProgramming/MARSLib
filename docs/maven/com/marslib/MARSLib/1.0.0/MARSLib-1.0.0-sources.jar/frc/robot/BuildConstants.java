package frc.robot;

/** Automatically generated file containing build version information. */
public final class BuildConstants {
  public static final String MAVEN_GROUP = "";
  public static final String MAVEN_NAME = "MARSLib";
  public static final String VERSION = "unspecified";
  public static final int GIT_REVISION = 292;
  public static final String GIT_SHA = "c86ab516373ee4cc5634bc35583f0ba0254897a3";
  public static final String GIT_DATE = "2026-04-13 13:57:05";
  public static final String GIT_BRANCH = "master";
  public static final String BUILD_DATE = "2026-04-13 17:57:43 UTC";
  public static final long BUILD_UNIX_TIME = 1776103063918L;
  public static final int DIRTY = 1;

  private BuildConstants() {}
}
