package frc.robot;

/** Automatically generated file containing build version information. */
public final class BuildConstants {
  public static final String MAVEN_GROUP = "";
  public static final String MAVEN_NAME = "MARSLib";
  public static final String VERSION = "unspecified";
  public static final int GIT_REVISION = 298;
  public static final String GIT_SHA = "ac03097a16dcfe22f9a1835451567e34af27b1ef";
  public static final String GIT_DATE = "2026-04-13 14:10:40";
  public static final String GIT_BRANCH = "master";
  public static final String BUILD_DATE = "2026-04-13 18:11:21 UTC";
  public static final long BUILD_UNIX_TIME = 1776103881190L;
  public static final int DIRTY = 1;

  private BuildConstants() {}
}
