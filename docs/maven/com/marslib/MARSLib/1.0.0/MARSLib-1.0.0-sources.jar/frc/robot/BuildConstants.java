package frc.robot;

/** Automatically generated file containing build version information. */
public final class BuildConstants {
  public static final String MAVEN_GROUP = "";
  public static final String MAVEN_NAME = "MARSLib";
  public static final String VERSION = "unspecified";
  public static final int GIT_REVISION = 270;
  public static final String GIT_SHA = "07cb72d405e893d455c8ecae23cced3c84d643a1";
  public static final String GIT_DATE = "2026-04-13 12:52:36";
  public static final String GIT_BRANCH = "master";
  public static final String BUILD_DATE = "2026-04-13 16:53:22 UTC";
  public static final long BUILD_UNIX_TIME = 1776099202691L;
  public static final int DIRTY = 1;

  private BuildConstants() {}
}
