package frc.robot;

/** Automatically generated file containing build version information. */
public final class BuildConstants {
  public static final String MAVEN_GROUP = "";
  public static final String MAVEN_NAME = "MARSLib";
  public static final String VERSION = "unspecified";
  public static final int GIT_REVISION = 322;
  public static final String GIT_SHA = "51ff25fafe94dfd32b83fc15fc73e7d34219e9ac";
  public static final String GIT_DATE = "2026-04-13 17:41:55";
  public static final String GIT_BRANCH = "master";
  public static final String BUILD_DATE = "2026-04-13 21:42:59 UTC";
  public static final long BUILD_UNIX_TIME = 1776116579901L;
  public static final int DIRTY = 1;

  private BuildConstants() {}
}
